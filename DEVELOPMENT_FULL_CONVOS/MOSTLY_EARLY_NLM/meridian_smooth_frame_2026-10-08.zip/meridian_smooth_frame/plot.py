import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
P=Path('/mnt/data/meridian_smooth_frame')
M,R=.15,1.0
a=np.sqrt(1-2*M/R);k=2*M/R**3;C=4/(1+a)**3
rhoS=R*(1+a)**2/4
rho=np.linspace(0,1.35,1401)
z=k*C*C*rho*rho
lamIn=2*C/(1+z)
NIn=((3*a-1)+(3*a+1)*z)/(2*(1+z))
lamEx=(1+M/(2*np.maximum(rho,1e-12)))**2
NEx=(1-M/(2*np.maximum(rho,1e-12)))/(1+M/(2*np.maximum(rho,1e-12)))
lam=np.where(rho<=rhoS,lamIn,lamEx)
N=np.where(rho<=rhoS,NIn,NEx)
fig,ax=plt.subplots(figsize=(8,5))
ax.plot(rho,lam,label='Spatial frame stretch  λ(ρ)',linewidth=2)
ax.plot(rho,N,label='Temporal frame factor  N(ρ)',linewidth=2)
ax.axvline(rhoS,linestyle='--',linewidth=1,label='Stellar boundary')
ax.set(xlabel='Isotropic Euclidean radius ρ / R',ylabel='Dimensionless frame factor',title='Exact constant-density star in a smooth 4D frame')
ax.legend();ax.grid(alpha=.25);fig.tight_layout();fig.savefig(P/'smooth_frame_profiles.png',dpi=210);plt.close(fig)
# exact geometry of radial/areal coordinate map
rr=np.where(rho<=rhoS,lamIn*rho,rho*(1+M/(2*np.maximum(rho,1e-12)))**2)
fig,ax=plt.subplots(figsize=(7,5))
ax.plot(rho,rr,label='Areal radius r(ρ)',linewidth=2)
ax.plot(rho,rho,linestyle=':',label='Unstrained r=ρ')
ax.axvline(rhoS,linestyle='--',linewidth=1,label='Boundary')
ax.scatter([rhoS],[R],s=40,zorder=3)
ax.set(xlabel='Euclidean radial coordinate ρ / R',ylabel='Areal radius r / R',title='Exact radial deformation map, regular at center')
ax.legend();ax.grid(alpha=.25);fig.tight_layout();fig.savefig(P/'radial_mapping.png',dpi=210);plt.close(fig)
# constant scalar curvature in interior, vacuum exterior
R3=np.where(rho<=rhoS,12*M/R**3,0)
fig,ax=plt.subplots(figsize=(8,4))
ax.plot(rho,R3,linewidth=2,label='Intrinsic spatial Ricci scalar  ³R')
ax.axvline(rhoS,linestyle='--',linewidth=1,label='Boundary')
ax.set(xlabel='Isotropic Euclidean radius ρ / R',ylabel='³R  (R=1)',title='Spatial curvature: exact density constraint, not an angular fit')
ax.legend();ax.grid(alpha=.25);fig.tight_layout();fig.savefig(P/'spatial_curvature.png',dpi=210);plt.close(fig)
print('plots:',[x.name for x in P.glob('*.png')])
# Exact invariant of static time-normal congruence, despite fixed background e4.
b=(1-z)/(1+z)
accIn=k*(lamIn*rho)/(3*a-b)
rrSafe=np.maximum(rr,0.5)
accEx=M/(rrSafe*rrSafe*np.sqrt(np.maximum(1-2*M/rrSafe,1e-12)))
acc=np.where(rho<=rhoS,accIn,accEx)
fig,ax=plt.subplots(figsize=(8,5))
ax.plot(rho,acc,linewidth=2,label='Physical static-congruence acceleration |∇ᵤu|')
ax.plot(rho,np.zeros_like(rho),linestyle=':',label='Background directional change |∂e₄| = 0')
ax.axvline(rhoS,linestyle='--',linewidth=1,label='Boundary')
ax.set(xlabel='Isotropic Euclidean radius ρ / R',ylabel='Acceleration magnitude × R',title='Fixed coordinate time direction does not mean zero geometric turning')
ax.grid(alpha=.25);ax.legend();fig.tight_layout();fig.savefig(P/'normal_acceleration_invariant.png',dpi=210);plt.close(fig)
