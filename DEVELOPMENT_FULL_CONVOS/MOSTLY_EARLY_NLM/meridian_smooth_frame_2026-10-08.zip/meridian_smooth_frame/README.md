# Meridian: smooth stellar-interior tetrad test

Date: 2026-10-08 UTC / 2026-10-07 EDT. SANDBOXED mathematical representation, not a physical claim.

Run `python verify.py` to check symbolic identities (requires SymPy). Run `python plot.py` to regenerate precision figures (requires NumPy and Matplotlib).

The full source/provenance checkpoint is committed to:
https://github.com/Satobloc/HsH/blob/main/WORKSPACES/MERIDIAN/SANDBOX/2026-10-08_SMOOTH_INTERIOR_FRAME_GATE.md

Main result: A smooth, exact constant-density stellar interior can be expressed with one radial spatial-frame profile λ and a lapse N algebraically determined by λ. The preferred time normal can remain constant. Therefore the cusp in the previous conformal-Householder ansatz is not an unavoidable property of a 4D representation. The new construction is a standard GR tetrad, not a derivation of dynamics or a new prediction.

Source reads: SAT archive `2026/SAT MATH — BACKBONE.txt` (opening 320 lines); HsH `DEVELOPMENT_FULL_CONVOS/30SEP26_DUMP/SAT Math Extension.txt` (opening 320 lines) and `DEVELOPMENT_FULL_CONVOS/7OCT26_A_GRADE_MINEABLES/KEY CONCEPT - IRI.txt` (opening 200 lines). External resources used for routing only.

Further exact result: the fixed Euclidean time direction e4 can coexist with nonzero *covariant* acceleration of the static normalized GR time normal. Inside the star, |∇_u u| = k r/(3a-b), and the static foliation has K_ij=0. This was verified in SymPy and plotted in `normal_acceleration_invariant.png`. Companion GitHub checkpoint: https://github.com/Satobloc/HsH/blob/main/WORKSPACES/MERIDIAN/SANDBOX/2026-10-08_STATIC_NORMAL_ACCELERATION_GATE.md
