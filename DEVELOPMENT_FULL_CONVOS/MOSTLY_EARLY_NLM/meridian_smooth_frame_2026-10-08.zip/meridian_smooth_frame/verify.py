import sympy as s
rho,M,R=s.symbols('rho M R',positive=True,real=True)
a=s.sqrt(1-2*M/R)
k=2*M/R**3
C=4/(1+a)**3
h=k*C**2
z=h*rho**2
lam=2*C/(1+z)
N=((3*a-1)+(3*a+1)*z)/(2*(1+z))
r=lam*rho
b=(1-z)/(1+z)
checks={
 'areal radial identity dr/dρ=λb':s.simplify(s.diff(r,rho)-lam*b),
 'interior lapse identity N=(3a-b)/2':s.simplify(N-(3*a-b)/2),
 'center λ radial derivative':s.simplify(s.diff(lam,rho).subs(rho,0)),
 'center N radial derivative':s.simplify(s.diff(N,rho).subs(rho,0)),
 'spatial Ricci scalar -8 ψ^-5 Δψ = 6k':None,
 'lapse elliptic residual':None,
}
psi=s.sqrt(2*C)/s.sqrt(1+z)
lap_psi=s.simplify(s.diff(psi,rho,2)+2*s.diff(psi,rho)/rho)
R3=s.simplify(-8*lap_psi/psi**5)
checks['spatial Ricci scalar -8 ψ^-5 Δψ = 6k']=s.simplify(R3-6*k)
eps=3*M/(4*s.pi*R**3)
p=eps*(b-a)/(3*a-b)
lapN=s.simplify(s.diff(lam*rho**2*s.diff(N,rho),rho)/(lam**3*rho**2))
checks['lapse elliptic residual']=s.simplify(s.factor(lapN-4*s.pi*N*(eps+3*p)))
rhoS=R*(1+a)**2/4
lamExt=(1+M/(2*rho))**2
NExt=(1-M/(2*rho))/(1+M/(2*rho))
for key,f1,f2 in [('λ',lam,lamExt),('N',N,NExt),('λ prime',s.diff(lam,rho),s.diff(lamExt,rho)),('N prime',s.diff(N,rho),s.diff(NExt,rho))]:
 checks['surface '+key]=s.simplify(s.factor((f1-f2).subs(rho,rhoS)))
checks['surface r=R']=s.simplify((r-R).subs(rho,rhoS))
for label,expr in checks.items():print(label, ':',expr)
assert all(v==0 for v in checks.values())
print('PASS: all symbolic checks')
for compact in [.05,.15,.30,.40]:
 params={M:compact,R:1}
 print('M/R=',compact,'rho_surface=',float(rhoS.subs(params)),'N0=',float(N.subs(params).subs(rho,0)),'lambda0=',float(lam.subs(params).subs(rho,0)),'R3=',float(R3.subs(params)))
print('Interior lapse as affine function of λ:',s.simplify(N-((3*a+1)/2-lam/(2*C))))
print('Exterior lapse from λ:',s.simplify(NExt-(2/s.sqrt(lamExt)-1)))
# Geometric acceleration of the static unit-time congruence u=N^-1∂τ.
# a_mu=∂_mu ln N; |a| = |N'|/(λ N) in isotropic radius.
a_iso=s.simplify(s.diff(N,rho)/(lam*N))
a_areal=s.simplify(k*r/(3*a-b))
print('Static congruence proper acceleration equality:',s.simplify(a_iso-a_areal))
print('Surface acceleration equals M/(R² a):',s.simplify((a_iso-M/(R**2*a)).subs(rho,rhoS)))
print('Center acceleration:',s.simplify(a_iso.subs(rho,0)))
assert s.simplify(a_iso-a_areal)==0
assert s.simplify((a_iso-M/(R**2*a)).subs(rho,rhoS))==0
